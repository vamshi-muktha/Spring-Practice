package com.tcs.assessment4.exception;

public class AccountNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public AccountNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
